import { Component } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';

  loggedIn;
  userName;

  constructor(
    private auth:AuthService,
    private router: Router
  ) { 
    this.authUser()
  }

  authUser(){
    this.loggedIn = this.auth.isAuthenticated()
    if(this.loggedIn) {
        this.userName = this.auth.getUserData()
    }
  }
  logout(){ 
    localStorage.clear()
    this.router.navigate(['/login'])
  }
}
