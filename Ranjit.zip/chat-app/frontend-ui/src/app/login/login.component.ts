import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { UserService } from '../services/user.service';
import { SnackbarService } from '../services/snackbar.service';
import { Router } from '@angular/router';


/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return control.dirty && form.invalid;
  }
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [UserService]
})
export class LoginComponent implements OnInit {

  userForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private user: UserService,
    private snack: SnackbarService,
    private router: Router
  ) { }
  usernameFormControl = new FormControl('', Validators.compose([
    Validators.required,
  ]));
  passwordFormControl = new FormControl('', Validators.compose([
    Validators.required,
    Validators.minLength(5),
  ]));

  matcher = new MyErrorStateMatcher();

  ngOnInit(): void {
    this.userForm = this.fb.group({
      username: this.usernameFormControl,
      password: this.passwordFormControl
    })
  }
  loginUser() {
    this.userForm.value.remember_me = true;
    this.user.login(this.userForm.value).subscribe(response => {
      var res: any = response
      if (!res.isPresent) {
        this.snack.openSnack("Check username")
      } else if (!res.correctPassword) {
        this.snack.openSnack("Check password")
      } else {
        localStorage.setItem('userAuth',res.user.username)
        this.router.navigate(['/chat'])
      }
    }, error => {

    })
  }
}
