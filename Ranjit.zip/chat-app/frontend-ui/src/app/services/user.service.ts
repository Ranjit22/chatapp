import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) { }

  signup(model){
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.httpClient.post(environment.apiURL+'api/signup',model, { headers: headers }).pipe(catchError(this.handleError))
  }
  login(model):any{
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.httpClient.post(environment.apiURL+'api/login',model, { headers: headers }).pipe(catchError(this.handleError))
  }
  getUsers() {
    return this.httpClient.get(environment.apiURL+'api/users');
  }
  getLoggedInUser() {
    return localStorage.getItem('userAuth');
  }
  getChatRoomsChat(chatRoom) {
    return this.httpClient.get(environment.apiURL+'chatroom/' + chatRoom);
  }
  handleError(error) {

    let errorMessage = '';
 
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else { 
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    } 
    return throwError(error);
 
  }
}
