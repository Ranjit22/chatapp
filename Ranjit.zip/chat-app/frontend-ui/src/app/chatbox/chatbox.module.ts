import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { ChatboxComponent } from './chatbox.component';
import { SharedModule } from '../shared/shared.module';

const login:Routes = [
  { path: '', component:ChatboxComponent }
]

@NgModule({
  declarations: [ChatboxComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(login),
    SharedModule
  ]
})
export class ChatBoxModule { }
