import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { WebsocketService } from '../services/websocket.service';
import { SnackbarService } from '../services/snackbar.service';

@Component({
  selector: 'app-chatbox',
  templateUrl: './chatbox.component.html',
  styleUrls: ['./chatbox.component.css'],
  providers: [WebsocketService]
})
export class ChatboxComponent implements OnInit {
  Users;
  private username: string;
  private chatroom;
  private message: string;
  messageArray;
  private isTyping = false;
  msgShow = false;


  constructor(
    private userservice:UserService,
    private webSocketService: WebsocketService,
    private userService: UserService,
    private snack: SnackbarService
  ){ 
    this.webSocketService.newMessageReceived().subscribe(data => {
      this.messageArray.push(data);
      this.isTyping = false;
    });
    this.webSocketService.receivedTyping().subscribe(bool => {
      this.isTyping = bool.isTyping;
    });
  }
  ngOnInit(): void {
    this.userservice.getUsers().subscribe(users => {
      this.Users = users;
    });
  }

  chatBox(user){
    const currentUser = this.userService.getLoggedInUser();
    this.username = user.username;
    if ( currentUser < this.username) {
      this.chatroom = currentUser.concat(this.username);
    } else {
      this.chatroom = this.username.concat(currentUser);
    }
    this.webSocketService.joinRoom({user: this.userService.getLoggedInUser(), room: this.chatroom});
    this.userService.getChatRoomsChat(this.chatroom).subscribe(messages => {
      this.msgShow = true;
      this.messageArray = messages
    });
  }
  sendMessage() {
    if(this.message) {
      this.webSocketService.sendMessage({room: this.chatroom, user: this.userService.getLoggedInUser(), message: this.message});
      this.message = '';
    } else {
      this.snack.openSnack("Please enter any message")
    }
    
  }

  typing() {
    this.webSocketService.typing({room: this.chatroom, user: this.userService.getLoggedInUser()});
  }

}
