import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { SnackbarService } from '../services/snackbar.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers: [UserService]
})
export class SignupComponent implements OnInit {
  userForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private user: UserService,
    private snack: SnackbarService
  ) { }


  nameFormControl = new FormControl('', [
    Validators.required
  ]);
  emailFormControl = new FormControl('', Validators.compose([
    Validators.required,
    Validators.email,
  ]));
  passwordFormControl = new FormControl('', Validators.compose([
    Validators.required,
    Validators.minLength(5),
  ]));

  verifyPasswordFormControl = new FormControl('', Validators.compose([
    Validators.required,
    Validators.minLength(5),
  ]));


  ngOnInit(): void {
    this.userForm = this.fb.group({
      username: this.nameFormControl,
      email: this.emailFormControl,
      password: this.passwordFormControl,
      verifyPassword: this.verifyPasswordFormControl
    }, {
      validator: this.passwordValidator
    })
  }


  passwordValidator(form: FormGroup) {
    const condition = form.get('password').value !== form.get('verifyPassword').value;
    return condition ? { passwordsDoNotMatch: true } : null;
  }

  addUser() {
    this.userForm.value.password_confirmation = this.userForm.value.verifyPassword;
    this.user.signup(this.userForm.value).subscribe(response => {
      var res: any = response
      if (res.user_already_signed_up) {
        this.snack.openSnack("Already registered!! Please login")
      } else {
        this.router.navigate(['/login'])
      }
    }, error => {

    })
  }

}
